#!/usr/local/bin/perl -w

# this program computes the pernode packets sent
# Trace file format
# PRD -- Indicates a packet is received
# MBN -- specifies a particular node to be a misbehaving node
# MBS -- indicates that a specifed node started misbehaving
# MBE -- indicates that a specified node ended misbehaving
# MBD -- indicates that a particular transmission was identified to be misbehaving 
#                (if the transmission was from a misbehaving node, then we have a correct
#                 prediction, otherwise we have an incorrect prediction)
#
# The parsing code below has details on the arguments for each trace element
# The trace throughput values are in number of data packets received over the 
# simulation duration. That number has to be multiplied by packet size and divided by
# length of simulation to obtain throughput in bits per second


# Global declarations

$correctPrediction = 0;
$misPrediction = 0;
$correctPackets = 0;
$misPackets = 0;



#------------------------ Main code ---------------------



if( $#ARGV >= 3) {
open(INPUT,$ARGV[0]) || die " cannot open $ARGV[0]";
open(OUTPUT_ABS,">>".$ARGV[1]) || die " cannot open $ARGV[1]";
open(OUTPUT_DET,">>".$ARGV[2]) || die " cannot open $ARGV[2]";
}
else
{
    die "Usage: <input file> <abstract output file> <detail output file> <index value for abstract>\n";
}



while(<INPUT>)
{
  #  print $_;
   # if(/^r (\d+).\d+ _(\d+)_ AGT  --- \d+ \S+ \d+ \[\S+ \S+ \S+ \S+\] ------- \[(\d+)/o)
     if(/^rp (\d+) (\d+)/o)
    {
	$curNode=$1;
	if(defined($arrayOutput{$curNode}) )
	{
	    $arrayOutput{$curNode} = $arrayOutput{$curNode} + $2;
	}
    }
    elsif(/^PRD (\d+).\d+ (\d+) (\d+) (\d+)/o)
    {
	$curNode=$2;
	$actual=$3;
	$expected=$4;
	
	
     
	if(defined($misbehavingNode{$curNode}) )
	{
	    if( $misbehavingNode{$curNode} eq "TRUE" )
	    {
		$misPackets++;
	    }
	    else
	    {
		$correctPackets++;
	    }
	}
	else
	{
	    $correctPackets++;
	}
	if(defined($actualNum{$curNode}) )
	{
	    $actualNum{$curNode}+=$actual;
	    $expectedNum{$curNode}+=$expected;
	    $totalPackets{$curNode}++;
	}
	else
	{
	    $actualNum{$curNode}=$actual;
	    $expectedNum{$curNode}=$expected;
	    $totalPackets{$curNode}=1;
	}
    }
    elsif(/^MBN (\d+)/o)
    {
	$misbehavingNode{$1}="TRUE";
    }
    elsif(/^MBS (\d+).\d+ (\d+)/o)
    {
	$curNode=$2;
	$misbehavingNode{$curNode}="TRUE";
	
    }
    elsif(/^MBE (\d+).\d+ (\d+)/o)
    {
	$curNode=$2;
	$misbehavingNode{$curNode}="FALSE";
	
    }
    elsif(/^MBD (\d+).\d+ (\d+) (\d+)/o)
    {
	$curNode=$2;
	if( defined($misbehavingNode{$curNode}) )
	{
	    if($misbehavingNode{$curNode} eq "TRUE")
	    {
		$correctPrediction++;
	    }
	    else
	    {
		if(defined ($nodeMisPrediction{$curNode}) )
		{
		    $nodeMisPrediction{$curNode}++;
		}
		else
		{
		    $nodeMisPrediction{$curNode}=1;
		}
		$misPrediction++;
	    }
	}
	else
	{
	    if(defined ($nodeMisPrediction{$curNode}))
	    {
		$nodeMisPrediction{$curNode}++;
	    }
	    else
	    {
		$nodeMisPrediction{$curNode}=1;
	    }
	    $misPrediction++;
	}

	if( defined($backoffAdded{$curNode} ) ) {
	    $backoffAdded{$curNode}+=$3; }
	else {
	    $backoffAdded{$curNode}=$3; }
    }
    elsif(/^PARAM (\d+)/o)
    {

    }    
    elsif(/^NODES (\d+)/o)
    {
    }
    elsif(/^SENDER (\d+)/o)
    {
	$arrayOutput{$1} = 0;
    }
    else
    {
    }
    
}

close(INPUT);

@nodes = keys(%arrayOutput);
$total_tput = 0;
$num_nodes = 0;
$max_tput = -1;
$min_tput = 1000000;


$num_misbnodes =0;
$max_misbtput=-1;
$min_misbtput=1000000;
$misb_tput = 0;



$max_misPrediction = -1;
$max_misbNode = -1 ;



foreach $i (@nodes)
{
# Code added to get an estimate of the variance
    if( defined($totalPackets{$i}) && $totalPackets{$i} > 0 )
    {
	$dev_per_pkt = ($actualNum{$i} - $expectedNum{$i}) / $totalPackets{$i};
	print "Deviation per RTS for $i = $dev_per_pkt,total RTS = $totalPackets{$i}\n";  
    }  
	  
	   
    print("Packets received from $i =  $arrayOutput{$i}");
    if( defined($misbehavingNode{$i}) )
    {
	$misb_tput += $arrayOutput{$i};
	$num_misbnodes ++ ;

	
	
	if($arrayOutput{$i} > $max_misbtput) {
	    $max_misbtput = $arrayOutput{$i}; }
	if($arrayOutput{$i} < $min_misbtput) {
	    $min_misbtput = $arrayOutput{$i}; }
    }
    else
    {
	if($arrayOutput{$i} > $max_tput) {
	    $max_tput = $arrayOutput{$i}; }
	if($arrayOutput{$i} < $min_tput) {
	     $min_tput = $arrayOutput{$i}; }
    }   
    
    
    if( defined($nodeMisPrediction{$i}) &&  defined($totalPackets{$i}) )
    {
	$nodeMisPredictionPERC{$i}=100*$nodeMisPrediction{$i}/$totalPackets{$i}; 
	print(", Total RTS = $totalPackets{$i}, Misprediction = $nodeMisPrediction{$i}, % = $nodeMisPredictionPERC{$i} \n");
    }
    else
    {
	print("\n");
	
	if(!defined($totalPackets{$i})) {  $totalPackets{$i}=0;	}
	   
	$nodeMisPrediction{$i}=0;   
	$nodeMisPredictionPERC{$i}=0;
    }
    
    if( $nodeMisPredictionPERC{$i} > $max_misPrediction )
    {
	$max_misPrediction = $nodeMisPredictionPERC{$i} ;
	$max_misbNode = $i ;
    }
  
    
    $total_tput += $arrayOutput{$i};
    $num_nodes ++ ;
}



$average_tput = 0; 
$average_misbtput=0;
$correctPerc = 0;
$misPerc = 0;


if( $num_nodes > 0 ) {
    $average_tput = int $total_tput / $num_nodes ; }

if( $num_misbnodes > 0 ) {
    $average_misbtput = int $misb_tput / $num_misbnodes ; }


if( $misPackets > 0 ) {
    $correctPerc = int $correctPrediction / $misPackets * 100; }

if( $correctPackets > 0 ) {
    $misPerc = int $misPrediction / $correctPackets * 100; }

$max_tput = abs $max_tput;
$max_misbtput = abs $max_misbtput;
$max_misPrediction = int $max_misPrediction;




# WRITE TO ABSTRACT FILE
print OUTPUT_ABS "\nSTART_REC ----------------------------------\n";
print OUTPUT_ABS "#INDEX MIS_PERC AVG_TPUT MISBTPUT\n";
print OUTPUT_ABS "$ARGV[3] $misPerc $average_tput $average_misbtput \n";

print OUTPUT_ABS "END_REC\n"; # end of a record of data

close(OUTPUT_ABS);

# WRITE TO DETAIL FILE
print OUTPUT_DET "\nSTART_REC ----------------------------------\n";
print OUTPUT_DET "#INDEX MIS_PERC AVG_TPUT AVG_MISBTPUT \n";
print OUTPUT_DET "#$ARGV[3] $misPerc $average_tput $average_misbtput\n";

foreach $i (@nodes)
{

    print OUTPUT_DET "$i $arrayOutput{$i} ";
    print OUTPUT_DET "$totalPackets{$i} $nodeMisPrediction{$i} $nodeMisPredictionPERC{$i}";


    if( defined($backoffAdded{$i} )) {
	print OUTPUT_DET " $backoffAdded{$i}\n"; }
    else {
	print OUTPUT_DET "0\n"; }
}
print OUTPUT_DET "END_REC ----------------------------------\n"; # end of a record of data

close(OUTPUT_DET);


exit 0;







