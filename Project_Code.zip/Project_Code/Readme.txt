1) Install NS2.35 http://www.isi.edu/nsnam/ns/tutorial/index.html
2) Add MAC 802.11mb.cc and MAC 802.11mb.h files in mac
3) change the physical sensing channel to shadowing channel model.
4) Replace dsr folder and mac files
5) Run the make file ./make and validate it ./validate
6) Run the tcl file ModifiedMAC.tcl
7) Run the Perl Script Perl Alltest.pl
